# JaaS 

**J**enkins **a**s **a** **S**ervice is introduced as a self service model. We have provided templates (`jenkins-persistent.json` & `jenkins-slave-builder-template.yaml`) here which you need to run on Redhat's Openshift Platform (OCP) to bring up Jenkins Master and Jenkins Slave image respectively.

To learn more about JaaS, please visit our [confluence page](https://confluence.pitneycloud.com/display/ISP/Jenkins+as+a+Service)
### Pre-requisites
Please ensure you read and execute the following as pre-requisite steps to provision a Jenkins server for yourself.


1. Make sure you have openshift CLI (minimum version 3.7) on you machine and added to PATH variable<br />
    Link to CLI: "https://docs.openshift.org/latest/cli_reference/get_started_cli.html#installing-the-cli"

2. Create SSH- keypair to be used by team USING ssh-keygen or putty-gen<br />
    http://dbygitmsprod.pbi.global.pvt/help/ssh/README

Please refer to more documentation at [wiki](https://gitlab.pitneycloud.com/OCP/JaaS/wikis/home) that you need to do before continuing here.


### JaaS Files and Directories:

To understand the folder structure here.

**jenkins-persistent.json** : This json template is responsible to bring up the JaaS master and renders passing data objects required to bring up Jenkins master. This template would requires [minimum alteration](https://gitlab.pitneycloud.com/OCP/JaaS/wikis/Update%20the%20template%20for%20jenkins%20master) per requirement by Product Teams within Pitney Bowes.

**jenkins-persistent-mvn.json** : This template is responsible to bring up JaaS Master similar to jenkins-persistent.json, however it will create **additional Persistent volume** to save **.m2 folder data** across builds. This template would requires [minimum alteration](https://gitlab.pitneycloud.com/OCP/JaaS/wikis/Update%20the%20template%20for%20jenkins%20master) per requirement by Product Teams within Pitney Bowes.

**jenkins-slave-builder-template.yaml** : This is yaml template responsible for baking the docker images that will be used to spin up containerized slaves. These slaves can be configured to run the jobs. This template will require [minimal modification](https://gitlab.pitneycloud.com/OCP/JaaS/wikis/Update%20the%20existing%20template%20for%20jenkins%20slave) per requirement by Product Teams within Pitney Bowes.

**jenkins-master-config** : This directory holds the subdirectories to restore Jobs, Plugins and other configurations when bringing up a new master. The subdirectories may include:-  plugins, jobs, nodes and other configurations.
* **\Plugins.txt** : This .txt will contain the plugin id (and not names), along with version specifically needed. Format - openshift-sync:1.0.3 . If version is not specified, latest version available is jenkins update repo will be installed.
* **\configuration\jobs** : This directory will contain the jobs those are to be restored in JaaS master.
* **\configuration\nodes** : This directory will contain nodes those are to be restored in JaaS master.
* **\configuration\plugins** : This directory will contain the plugins (.hpi and .jpi formats) those are to be restored in JaaS master. Especially non-standardized plugins

**slave** : This directory would contain the slaves configurations such as Dockerfile and configuration directory 
* **Dockerfile** : This Dockerfile contains configurations that are to be done on top of raw image taken. This raw image can be rhel\rhel, centOS, library/ubuntu:14.04 etc. This docker file will require modification depending on image needed to churn up slave.
* **configuration**: This directory contains run-jnlp-client, passwd.template and some other .xml files which are needed to configure slave for some day-to-day activities (like uploading artifacts, etc) that it must perform.

**utilities** : This directory contains addional custom templates. 

**Readme.md** : It contains all the commands that are required to bring up JaaS Master and build slave images.


### Jenkins-Master

connect to OCP - danbury instance:
```
$ oc login dby-ocp.pbi.global.pvt:8443
```
Run the following commands to bring up the **Jenkins master**.

1. To create a new project for a particular team (Also referred as namespace in Openshift's terminology)
```
    $ oc new-project {Project-Name}
```
    **eg:** oc new-project **toolsdev**
    
2. Create a secret which has the private key linked to access the gitlab repo.
```
    $ oc secrets new {SECRET-NAME} ssh-privatekey=$HOME/.ssh/{SECRET-FILE}
```
    **Note:** recommended way is to keep **{SECRET-NAME}** as **"{PROJECT-NAME}-secret"**
    
    **eg:** oc secrets new **toolsdev-secret** ssh-privatekey=$HOME/.ssh/id_rsa
    
3. Link the secret to the builder phase
```
    $ oc secrets link builder {SECRET-NAME}
```
4. Push the build image onto the OC platform.
```
    $ oc new-app -f jenkins-persistent.json
```
    Or For Pushing the build image with additional PVC for Maven, run below command
```
    $ oc new-app -f jenkins-persistent-mvn.json
```
5. Start Jenkins deployment and this brings up the Jenkins master.
```
    $ oc start-build jenkins
```

### Jenkins-slave image
`jenkins-slave-builder-template.yaml` will create a plain RHEL7 slave image.

If not conected, login to OCP - danbury instance:
```
$ oc login dby-ocp.pbi.global.pvt:8443
```


Run following steps to create **Jenkins-slave image**:

1. Give the Jenkins Pod service account rights to do API calls to OpenShift. This allows us to do the Jenkins Slave image discovery automatically
```
    $ oc policy add-role-to-user edit -z default -n {Project-Name}
```
2. Install the provided OpenShift templates
```
    $ oc create -f <name of slave template yaml file>    # For converting any S2I to Jenkins slave
```
eg: oc create -f jenkins-slave-builder-template.yaml      
    
3. Build Jenkins slave image.
```
    $ oc new-app <Name of template>
```
eg: oc new-app jenkins-slave-builder
